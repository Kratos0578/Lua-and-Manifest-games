-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(1643320)
addappid(1643321,0,"71c29e58911c13991edea02ac06db5f5991e43e52cdcd76c19126d657c4a38e7")
setManifestid(1643321,"8640144424682546685")

-- dlc
addappid(1661623) -- S.T.A.L.K.E.R. 2: Heart of Chornobyl - Pre-order Bonus
addappid(1661622) -- S.T.A.L.K.E.R. 2: Heart of Chornobyl - Season Pass
addappid(1661621) -- S.T.A.L.K.E.R. 2: Heart of Chornobyl - Ultimate Content
addappid(1661620) -- S.T.A.L.K.E.R. 2: Heart of Chornobyl - Deluxe Content
addappid(3332950) -- S.T.A.L.K.E.R. 2: Heart of Chornobyl — OST and Artbook
addtoken(3332950,"1610503047386597590")
addappid(3332951,0,"bbc6a28d2ba65a7efa0e1ae5d445e18b6c62f9b74f235761f95d3ec00201974e")
addappid(3332952,0,"ef8e291f55cede6e64183baac65954c90b2b4466ee9f1ca9b1f219f1a72073f0")
setManifestid(3332951,"8015766615333808098")
setManifestid(3332952,"5587306026943101600")