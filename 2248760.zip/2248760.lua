-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(2248760)
addappid(2248761, 1, "7e322b4c38775f33754204b8cb08844982412cd9d4b140906cfff0047a9b2843")
setManifestid(2248761, "4624350100558413527", 0)