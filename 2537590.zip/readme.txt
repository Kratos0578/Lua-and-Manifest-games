more then 1800 manifests is available on GFK discord server :3
join here https://discord.gg/xRkxTVuWCG